#Parts-List

  * 1x: Arduino UNO OR Mega
    * UNO: https://www.aliexpress.com/item/1pcs-New-2016-UNO-R3-ATmega328P-CH340G-MicroUSB-Compatible-for-Arduino-UNO-Rev-3-0-hei/32690342789.html?spm=2114.01010208.3.10.5TveFB&ws_ab_test=searchweb0_0,searchweb201602_2_10091_10090_10088_10089,searchweb201603_1&btsid=13d89c6d-caec-4cd2-acca-a5b2b240f4f5
    * Mega: https://www.aliexpress.com/item/Mega-2560-R3-CH340G-ATmega2560-16AU-MicroUSB-Compatible-for-Arduino-Mega-2560-With-Bootloader/32517341214.html?spm=2114.13010608.0.0.kJ4zgJ

  * 1x: 128X64 OLED DISPLAY http://www.ebay.com/itm/262600598291

  * 1x: DS1307 OR DS3231 RTC MODULE http://www.ebay.com/itm/141975887269

  * 1x: PUSH-BUTTON ROTARY ENCODER http://www.ebay.com/itm/Rotary-Encoder-Module-Brick-Sensor-Development-Board-Test-For-Arduino-New-D-/111861828395?hash=item1a0b7c0b2b:g:69IAAOSwaB5Xobfa
  
  * 1x: 110VAC DUAL OUTPUT 12VDC/5VDC STEP-DOWN BUCK CONVERTER http://www.ebay.com/itm/131645889700

  * 1x: 10K 5-PIN RESISTOR ARRAY http://www.ebay.com/itm/141420553564

  * 1x: 2 X 4 PIN HEADER http://www.ebay.com/itm/10-Pcs-2-54mm-2x4-Pin-8-Pin-Straight-Male-Shrouded-PCB-Box-header-IDC-Socket-/181147042425?hash=item2a2d348279:g:UYgAAOSwl-FXMtjS

  * 1x: 22uf 50V ELECTROLYIC CAPACITOR

  * 1x: 0.1uf CERAMIC CAPACITOR

  * 1x: CD4077B QUAD EXCLUSIVE NOR GATE (VIRTUALLY ANY GATE MAY BE USED, SIMPLY CHANGE THE OUTPUT VALUES IN THE SKETCH TO 
ACHIEVE THE DESIRED RESULT) http://www.ebay.com/itm/5-x-CD4077-4077-IC-CMOS-EXCLUSIVE-NOR-GATE-TEXAS-/320605284355?hash=item4aa5906803:g:qD4AAOxyNo9SvdcK

  * 4x: 2N2222 OR EQUIVALENT TRANSISTORS http://www.ebay.com/itm/20Pcs-2N2222A-2N2222-2222-NPN-Transistor-TO-92-US-Seller-/272401580990?hash=item3f6c6643be:g:Jq4AAOSwOVpXU63R

  * 4x: 5-PIN 12V COIL RELAYS P/N: SRD-12VDC-SL-C http://www.ebay.com/itm/131681426481
  
  * 4x: 125V 15A FEMALE PANEL MOUNT SOCKETS http://www.ebay.com/itm/122084629019

  * ?x: JUMPER WIRES (FEMALE), 16ga 110V SUITABLE WIRE, FEMALE SPADE TERMINALS, MISC. WIRING
  
  * 1x: PROJECT ENCLOSURE FOR CONTROLLER
  
  * 1x: WATER/SPLASH PROOF PROJECT ENCLOSURE FOR POWER SUPPLY
  
  * ?x: DESIRED LIGHTS/PUMPS/POTTING MATERIALS
